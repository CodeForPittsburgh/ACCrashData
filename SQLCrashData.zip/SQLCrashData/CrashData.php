<?php

include ('setup.php');
//$from = " FROM \"PoliceBlotter2\".incident";
//$where = " where incidentdate ='" . $yesterday . "'";
//$orderby = " order by incidenttype desc";
//echo $yesterday;
//echo "\n";
//$SQL = 'SELECT distinct "lat","lng","zone","incidentdate","incidenttime","incidentnumber","address","incidenttype","age","gender","councildistrict"' . $from . $where . $orderby;
$SQL = "SELECT 
DEC_LAT,
DEC_LONG,
STREET_NAME,
ROUTE,
SEGMENT,
OFFSETPG,
b.NAME,
CRASH_YEAR,
c.NAME,
TIME_OF_DAY,
d.NAME
    FROM ACCrashData as a ,
    municipalities as b,
    month_of_year as c,
    inj_severity as d
    where BICYCLE = 1 
    and a.MUNICIPALITY = b.ID 
    and a.CRASH_MONTH = c.ID
    and a.MAX_SEVERITY_LEVEL = d.ID
    and DEC_LAT is not null and crash_year > 2009
    order by STREET_NAME;
;";
echo $SQL;

$SQL2 = "SELECT 

d.NAME,count(d.name)
    FROM ACCrashData as a ,
    inj_severity as d
    where BICYCLE = 1 

    and a.MAX_SEVERITY_LEVEL = d.ID
    and DEC_LAT is not null and crash_year > 2009
    group by d.name
    order by d.name;
;";

$result = pg_query($dbconn, $SQL);
$count = pg_num_rows($result);
echo "Row count is " . $count;
if ($count > 0) {

    $dom = new DOMDocument("1.0");
    $node = $dom->createElement("markers");
    $parnode = $dom->appendChild($node);
//header("Content-type: text/xml");
// Iterate through the rows, adding XML nodes for each
    while ($row = pg_fetch_row($result)) {

        // ADD TO XML DOCUMENT NODE
        $node = $dom->createElement("marker");
        $newnode = $parnode->appendChild($node);
        $newnode->setAttribute("lat", $row[0]);
        $newnode->setAttribute("lng", $row[1]);
        $newnode->setAttribute("STREET_NAME", $row[2]);
        $newnode->setAttribute("ROUTE", $row[3]);
        $newnode->setAttribute("SEGMENT", $row[4]);
        $newnode->setAttribute("OFFSETPG", $row[5]);
        $newnode->setAttribute("NAME", $row[6]);
        $newnode->setAttribute("CRASH_YEAR", $row[7]);
        $newnode->setAttribute("CRASH_MONTH", $row[8]);
        $newnode->setAttribute("TIME_OF_DAY", $row[9]);
        $newnode->setAttribute("MAX_SEVERITY_LEVEL", $row[10]);

    }


    $filename = "./crashdata.xml";

    $dom->saveXML();
    echo $dom->saveXML();
    $dom->save($filename);
}

pg_close($dbconn);
echo "<br>" . "Disconnected from server " . "<br>";



