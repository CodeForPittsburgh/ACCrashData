<?php

#Add your connection information

$serverName = $PGserverName;
$port = $PGport;
$database = $PGdatabase;
$username = $PGusername;
$password = $PGpassword;
$connect_timeout = $PGconnect_timeout;

